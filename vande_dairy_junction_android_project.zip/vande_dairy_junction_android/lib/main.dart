import 'package:flutter/material.dart';

void main() => runApp(const VandeDairyApp());

class VandeDairyApp extends StatelessWidget {
  const VandeDairyApp({super.key});

  @override
  Widget build(BuildContext context) {
    const green = Color(0xFF123C32);
    return MaterialApp(
      title: 'Vande Dairy Junction',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: green),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF7F8F7),
        appBarTheme: const AppBarTheme(
          backgroundColor: green,
          foregroundColor: Colors.white,
          centerTitle: false,
        ),
        cardTheme: CardTheme(
          color: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: const BorderSide(color: Color(0xFFE5EAE7)),
          ),
        ),
      ),
      home: const LoginPage(),
    );
  }
}

enum UserRole { admin, salesman, retailer }

extension RoleLabel on UserRole {
  String get label => switch (this) {
        UserRole.admin => 'Admin',
        UserRole.salesman => 'Salesman',
        UserRole.retailer => 'Retailer',
      };
}

class Product {
  Product(this.name, this.unit, this.batch, this.expiry, this.qty, this.price);
  String name;
  String unit;
  String batch;
  DateTime expiry;
  int qty;
  double price;
}

class Retailer {
  Retailer(this.shop, this.contact);
  String shop;
  String contact;
}

class SalesOrder {
  SalesOrder(this.retailer, this.product, this.qty, this.total, this.status);
  String retailer;
  String product;
  int qty;
  double total;
  String status;
}

class PaymentEntry {
  PaymentEntry(this.retailer, this.amount, this.method, this.time);
  String retailer;
  double amount;
  String method;
  DateTime time;
}

class DemoStore {
  static final products = <Product>[
    Product('Amul Fresh Cream', '1 Ltr', 'FC-1026', DateTime(2026, 11, 20), 24, 210),
    Product('Amul Vanilla Royale', '100 ml', 'VR-1026', DateTime(2026, 11, 15), 48, 35),
    Product('Frozen Sweet Corn', '1 Kg', 'SC-1026', DateTime(2026, 11, 5), 12, 140),
  ];
  static final retailers = <Retailer>[
    Retailer('Shree Krishna Store', 'Demo account'),
  ];
  static final orders = <SalesOrder>[];
  static final payments = <PaymentEntry>[];
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  UserRole role = UserRole.admin;
  final phone = TextEditingController();
  final password = TextEditingController();

  @override
  void dispose() {
    phone.dispose();
    password.dispose();
    super.dispose();
  }

  void enterDemo() {
    Navigator.of(context).pushReplacement(MaterialPageRoute(
      builder: (_) => MainShell(role: role),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.all(22),
                    decoration: BoxDecoration(
                      color: const Color(0xFF123C32),
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: const Column(
                      children: [
                        Icon(Icons.local_drink_rounded, color: Colors.white, size: 54),
                        SizedBox(height: 12),
                        Text('Vande Dairy Junction',
                          style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
                        SizedBox(height: 4),
                        Text('Distribution Management', style: TextStyle(color: Color(0xFFD1E7DC))),
                      ],
                    ),
                  ),
                  const SizedBox(height: 28),
                  const Text('Demo Login', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  const Text('यह starter demo है। अभी वास्तविक authentication/database जुड़ा नहीं है।',
                    style: TextStyle(color: Colors.black54)),
                  const SizedBox(height: 18),
                  DropdownButtonFormField<UserRole>(
                    value: role,
                    decoration: const InputDecoration(labelText: 'Login role', border: OutlineInputBorder()),
                    items: UserRole.values.map((r) => DropdownMenuItem(value: r, child: Text(r.label))).toList(),
                    onChanged: (value) => setState(() => role = value ?? UserRole.admin),
                  ),
                  const SizedBox(height: 12),
                  TextField(controller: phone, keyboardType: TextInputType.phone,
                    decoration: const InputDecoration(labelText: 'Mobile number (demo only)', border: OutlineInputBorder())),
                  const SizedBox(height: 12),
                  TextField(controller: password, obscureText: true,
                    decoration: const InputDecoration(labelText: 'Password (demo only)', border: OutlineInputBorder())),
                  const SizedBox(height: 18),
                  FilledButton(
                    onPressed: enterDemo,
                    style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)),
                    child: const Text('Open Demo App'),
                  ),
                  const SizedBox(height: 10),
                  const Text('Demo में कोई भी role चुनकर आगे जा सकते हैं। वास्तविक login लागू करने से पहले secure backend जरूरी है.',
                    textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.black54)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key, required this.role});
  final UserRole role;
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;

  List<Widget> get pages => [
    DashboardPage(role: widget.role, onNavigate: (i) => setState(() => index = i)),
    const ProductsPage(),
    const OrdersPage(),
    const RetailersPage(),
    const PaymentsPage(),
  ];

  @override
  Widget build(BuildContext context) {
    final titles = ['Dashboard', 'Products & Stock', 'Orders', 'Retailers', 'Payments'];
    return Scaffold(
      appBar: AppBar(
        title: Text('Vande Dairy Junction · ${titles[index]}'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: Center(child: Text(widget.role.label, style: const TextStyle(fontWeight: FontWeight.w600))),
          )
        ],
      ),
      drawer: Drawer(
        child: SafeArea(
          child: Column(
            children: [
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(22),
                color: const Color(0xFF123C32),
                child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Icon(Icons.local_drink, color: Colors.white, size: 40),
                  SizedBox(height: 12),
                  Text('Vande Dairy Junction', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                  Text('Distribution App', style: TextStyle(color: Color(0xFFD1E7DC))),
                ]),
              ),
              for (var i = 0; i < titles.length; i++)
                ListTile(
                  leading: Icon([Icons.dashboard, Icons.inventory_2, Icons.shopping_cart, Icons.store, Icons.payments][i]),
                  title: Text(titles[i]),
                  selected: index == i,
                  onTap: () { setState(() => index = i); Navigator.pop(context); },
                ),
              const Spacer(),
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text('MVP starter · demo data only', style: TextStyle(color: Colors.black54, fontSize: 12)),
              ),
            ],
          ),
        ),
      ),
      body: IndexedStack(index: index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.inventory_2_outlined), selectedIcon: Icon(Icons.inventory_2), label: 'Stock'),
          NavigationDestination(icon: Icon(Icons.shopping_bag_outlined), selectedIcon: Icon(Icons.shopping_bag), label: 'Orders'),
          NavigationDestination(icon: Icon(Icons.store_outlined), selectedIcon: Icon(Icons.store), label: 'Retailers'),
          NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), selectedIcon: Icon(Icons.account_balance_wallet), label: 'Payments'),
        ],
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key, required this.role, required this.onNavigate});
  final UserRole role;
  final ValueChanged<int> onNavigate;

  @override
  Widget build(BuildContext context) {
    final sales = DemoStore.orders.fold<double>(0, (s, o) => s + o.total);
    final collections = DemoStore.payments.fold<double>(0, (s, p) => s + p.amount);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('नमस्ते, ${role.label}', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        const Text('आज का बिज़नेस ओवरव्यू', style: TextStyle(color: Colors.black54)),
        const SizedBox(height: 16),
        GridView.count(
          crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: 1.55,
          children: [
            MetricCard(title: 'आज की Demo Sales', value: '₹${sales.toStringAsFixed(0)}', icon: Icons.trending_up),
            MetricCard(title: 'Orders', value: '${DemoStore.orders.length}', icon: Icons.shopping_cart),
            MetricCard(title: 'Retailers', value: '${DemoStore.retailers.length}', icon: Icons.store),
            MetricCard(title: 'Collections', value: '₹${collections.toStringAsFixed(0)}', icon: Icons.payments),
          ],
        ),
        const SizedBox(height: 22),
        const Text('Quick Actions', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 8, children: [
          ActionChip(avatar: const Icon(Icons.inventory_2), label: const Text('Stock'), onPressed: () => onNavigate(1)),
          ActionChip(avatar: const Icon(Icons.add_shopping_cart), label: const Text('New Order'), onPressed: () => onNavigate(2)),
          ActionChip(avatar: const Icon(Icons.store), label: const Text('Retailers'), onPressed: () => onNavigate(3)),
          ActionChip(avatar: const Icon(Icons.payments), label: const Text('Collection'), onPressed: () => onNavigate(4)),
        ]),
        const SizedBox(height: 22),
        const Text('Expiry Watch', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        ...DemoStore.products.where((p) => p.expiry.difference(DateTime.now()).inDays <= 14).map((p) => Card(
          child: ListTile(
            leading: const Icon(Icons.warning_amber_rounded, color: Colors.deepOrange),
            title: Text(p.name),
            subtitle: Text('Batch ${p.batch} · Expiry ${dateText(p.expiry)}'),
            trailing: Text('${p.qty} ${p.unit}', textAlign: TextAlign.end),
          ),
        )),
        const SizedBox(height: 12),
        const Text('सभी आंकड़े sample/demo हैं; वास्तविक बिक्री या stock नहीं।', style: TextStyle(fontSize: 12, color: Colors.black54)),
      ],
    );
  }
}

class MetricCard extends StatelessWidget {
  const MetricCard({super.key, required this.title, required this.value, required this.icon});
  final String title;
  final String value;
  final IconData icon;
  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Icon(icon, color: const Color(0xFF123C32)),
        Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        Text(title, style: const TextStyle(fontSize: 12, color: Colors.black54)),
      ]),
    ),
  );
}

String dateText(DateTime d) => '${d.day.toString().padLeft(2, '0')}-${d.month.toString().padLeft(2, '0')}-${d.year}';

class ProductsPage extends StatefulWidget {
  const ProductsPage({super.key});
  @override
  State<ProductsPage> createState() => _ProductsPageState();
}

class _ProductsPageState extends State<ProductsPage> {
  final name = TextEditingController();
  final unit = TextEditingController(text: '1 Kg');
  final batch = TextEditingController();
  final qty = TextEditingController(text: '10');
  final price = TextEditingController(text: '0');
  DateTime expiry = DateTime.now().add(const Duration(days: 30));

  @override
  void dispose() { name.dispose(); unit.dispose(); batch.dispose(); qty.dispose(); price.dispose(); super.dispose(); }

  Future<void> addProduct() async {
    if (name.text.trim().isEmpty || batch.text.trim().isEmpty || (int.tryParse(qty.text) ?? 0) <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Product, batch और valid quantity भरें.')));
      return;
    }
    setState(() => DemoStore.products.add(Product(name.text.trim(), unit.text.trim(), batch.text.trim(), expiry, int.parse(qty.text), double.tryParse(price.text) ?? 0)));
    name.clear(); batch.clear();
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Demo stock entry added.')));
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('Batch-wise Inventory', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    const Text('हर batch के लिए expiry date और quantity रखें.', style: TextStyle(color: Colors.black54)),
    const SizedBox(height: 12),
    ...DemoStore.products.map((p) => Card(child: ListTile(
      leading: const Icon(Icons.inventory_2_outlined),
      title: Text(p.name),
      subtitle: Text('${p.unit} · Batch ${p.batch}\\nExpiry ${dateText(p.expiry)}'),
      isThreeLine: true,
      trailing: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Text('${p.qty}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        const Text('qty', style: TextStyle(fontSize: 11)),
      ]),
    ))),
    const SizedBox(height: 12),
    Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const Text('Add Demo Stock Batch', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      TextField(controller: name, decoration: const InputDecoration(labelText: 'Product name', border: OutlineInputBorder())),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(child: TextField(controller: unit, decoration: const InputDecoration(labelText: 'Unit', border: OutlineInputBorder()))),
        const SizedBox(width: 8),
        Expanded(child: TextField(controller: batch, decoration: const InputDecoration(labelText: 'Batch no.', border: OutlineInputBorder()))),
      ]),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(child: TextField(controller: qty, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Quantity', border: OutlineInputBorder()))),
        const SizedBox(width: 8),
        Expanded(child: TextField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Selling price ₹', border: OutlineInputBorder()))),
      ]),
      const SizedBox(height: 8),
      OutlinedButton.icon(onPressed: () async {
        final picked = await showDatePicker(context: context, initialDate: expiry, firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 3650)));
        if (picked != null) setState(() => expiry = picked);
      }, icon: const Icon(Icons.calendar_month), label: Text('Expiry: ${dateText(expiry)}')),
      const SizedBox(height: 8),
      FilledButton.icon(onPressed: addProduct, icon: const Icon(Icons.add), label: const Text('Add Batch')),
    ]))),
  ]);
}

class OrdersPage extends StatefulWidget {
  const OrdersPage({super.key});
  @override
  State<OrdersPage> createState() => _OrdersPageState();
}

class _OrdersPageState extends State<OrdersPage> {
  String? retailer;
  String? product;
  final quantity = TextEditingController(text: '1');

  @override
  void dispose() { quantity.dispose(); super.dispose(); }

  void createOrder() {
    final q = int.tryParse(quantity.text) ?? 0;
    final r = retailer;
    final p = product;
    if (r == null || p == null || q <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Retailer, product और quantity चुनें.')));
      return;
    }
    final item = DemoStore.products.firstWhere((x) => x.name == p);
    if (item.qty < q) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Demo stock में पर्याप्त quantity नहीं है.')));
      return;
    }
    setState(() {
      DemoStore.orders.insert(0, SalesOrder(r, p, q, q * item.price, 'Pending'));
      item.qty -= q;
    });
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Demo order created; stock updated in this session only.')));
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('Order Booking', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    const SizedBox(height: 12),
    Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      DropdownButtonFormField<String>(
        value: retailer,
        decoration: const InputDecoration(labelText: 'Retailer', border: OutlineInputBorder()),
        items: DemoStore.retailers.map((r) => DropdownMenuItem(value: r.shop, child: Text(r.shop))).toList(),
        onChanged: (v) => setState(() => retailer = v),
      ),
      const SizedBox(height: 10),
      DropdownButtonFormField<String>(
        value: product,
        decoration: const InputDecoration(labelText: 'Product', border: OutlineInputBorder()),
        items: DemoStore.products.map((p) => DropdownMenuItem(value: p.name, child: Text('${p.name} (${p.qty} available)'))).toList(),
        onChanged: (v) => setState(() => product = v),
      ),
      const SizedBox(height: 10),
      TextField(controller: quantity, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Quantity', border: OutlineInputBorder())),
      const SizedBox(height: 12),
      const Text('Billing policy: Cash / Online only · No credit', style: TextStyle(color: Color(0xFF123C32), fontWeight: FontWeight.w600)),
      const SizedBox(height: 12),
      FilledButton.icon(onPressed: createOrder, icon: const Icon(Icons.add_shopping_cart), label: const Text('Create Demo Order')),
    ]))),
    const SizedBox(height: 12),
    const Text('Recent Orders', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
    ...DemoStore.orders.map((o) => Card(child: ListTile(
      leading: const Icon(Icons.receipt_long),
      title: Text(o.product),
      subtitle: Text('${o.retailer} · Qty ${o.qty} · ${o.status}'),
      trailing: Text('₹${o.total.toStringAsFixed(0)}'),
    ))),
  ]);
}

class RetailersPage extends StatefulWidget {
  const RetailersPage({super.key});
  @override
  State<RetailersPage> createState() => _RetailersPageState();
}

class _RetailersPageState extends State<RetailersPage> {
  final shop = TextEditingController();
  final contact = TextEditingController();

  @override
  void dispose() { shop.dispose(); contact.dispose(); super.dispose(); }

  void addRetailer() {
    if (shop.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Shop name भरें.')));
      return;
    }
    setState(() => DemoStore.retailers.add(Retailer(shop.text.trim(), contact.text.trim().isEmpty ? 'Not provided' : contact.text.trim())));
    shop.clear(); contact.clear();
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('Retailer Master', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    const SizedBox(height: 10),
    ...DemoStore.retailers.map((r) => Card(child: ListTile(
      leading: const CircleAvatar(child: Icon(Icons.store)),
      title: Text(r.shop),
      subtitle: Text(r.contact),
    ))),
    Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const Text('Add Retailer', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      TextField(controller: shop, decoration: const InputDecoration(labelText: 'Shop name', border: OutlineInputBorder())),
      const SizedBox(height: 8),
      TextField(controller: contact, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Phone / contact', border: OutlineInputBorder())),
      const SizedBox(height: 10),
      FilledButton.icon(onPressed: addRetailer, icon: const Icon(Icons.person_add), label: const Text('Add Demo Retailer')),
    ]))),
  ]);
}

class PaymentsPage extends StatefulWidget {
  const PaymentsPage({super.key});
  @override
  State<PaymentsPage> createState() => _PaymentsPageState();
}

class _PaymentsPageState extends State<PaymentsPage> {
  String? retailer;
  String method = 'Cash';
  final amount = TextEditingController();

  @override
  void dispose() { amount.dispose(); super.dispose(); }

  void addPayment() {
    final a = double.tryParse(amount.text) ?? 0;
    if (retailer == null || a <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Retailer चुनें और सही amount भरें.')));
      return;
    }
    setState(() => DemoStore.payments.insert(0, PaymentEntry(retailer!, a, method, DateTime.now())));
    amount.clear();
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Demo collection entry added; actual payment not processed.')));
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('Cash / Online Collection', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    const SizedBox(height: 6),
    const Text('यह payment ledger demo है। कोई वास्तविक payment process नहीं होता.', style: TextStyle(color: Colors.black54)),
    const SizedBox(height: 12),
    Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      DropdownButtonFormField<String>(
        value: retailer,
        decoration: const InputDecoration(labelText: 'Retailer', border: OutlineInputBorder()),
        items: DemoStore.retailers.map((r) => DropdownMenuItem(value: r.shop, child: Text(r.shop))).toList(),
        onChanged: (v) => setState(() => retailer = v),
      ),
      const SizedBox(height: 10),
      TextField(controller: amount, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Amount ₹', border: OutlineInputBorder())),
      const SizedBox(height: 10),
      DropdownButtonFormField<String>(
        value: method,
        decoration: const InputDecoration(labelText: 'Payment method', border: OutlineInputBorder()),
        items: const [DropdownMenuItem(value: 'Cash', child: Text('Cash')), DropdownMenuItem(value: 'UPI / Online', child: Text('UPI / Online'))],
        onChanged: (v) => setState(() => method = v ?? 'Cash'),
      ),
      const SizedBox(height: 12),
      FilledButton.icon(onPressed: addPayment, icon: const Icon(Icons.add_card), label: const Text('Record Demo Collection')),
    ]))),
    const SizedBox(height: 12),
    Text('Collections total: ₹${DemoStore.payments.fold<double>(0, (s, p) => s + p.amount).toStringAsFixed(2)}',
      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
    ...DemoStore.payments.map((p) => Card(child: ListTile(
      leading: const Icon(Icons.receipt),
      title: Text('${p.retailer} · ₹${p.amount.toStringAsFixed(2)}'),
      subtitle: Text('${p.method} · ${dateText(p.time)}'),
    ))),
  ]);
}
