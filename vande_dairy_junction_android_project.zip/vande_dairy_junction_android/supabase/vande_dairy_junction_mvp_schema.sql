-- Starter database schema. Review and complete role-aware RLS before production.
create extension if not exists pgcrypto;
create type public.app_role as enum ('admin', 'salesman', 'retailer');
create type public.payment_method as enum ('cash', 'upi');
create type public.order_status as enum ('pending', 'approved', 'packed', 'dispatched', 'delivered', 'cancelled');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  phone text,
  role public.app_role not null default 'retailer',
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
create table public.retailers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  shop_name text not null,
  phone text not null,
  address text,
  assigned_salesman uuid references public.profiles(id),
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
create table public.products (
  id uuid primary key default gen_random_uuid(),
  sku text unique,
  name text not null,
  brand text,
  category text,
  unit text not null default 'piece',
  pack_size text,
  selling_price numeric(12,2) not null check (selling_price >= 0),
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
create table public.stock_batches (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id),
  batch_no text not null,
  received_date date not null default current_date,
  expiry_date date not null,
  qty_received numeric(12,3) not null check (qty_received > 0),
  qty_available numeric(12,3) not null check (qty_available >= 0),
  purchase_cost numeric(12,2) not null default 0 check (purchase_cost >= 0),
  unique (product_id, batch_no),
  check (expiry_date >= received_date),
  check (qty_available <= qty_received)
);
create table public.orders (
  id uuid primary key default gen_random_uuid(),
  order_no bigint generated always as identity unique,
  retailer_id uuid not null references public.retailers(id),
  created_by uuid not null references public.profiles(id),
  assigned_salesman uuid references public.profiles(id),
  status public.order_status not null default 'pending',
  subtotal numeric(12,2) not null default 0 check (subtotal >= 0),
  discount numeric(12,2) not null default 0 check (discount >= 0),
  tax numeric(12,2) not null default 0 check (tax >= 0),
  total numeric(12,2) not null default 0 check (total >= 0),
  notes text,
  created_at timestamptz not null default now()
);
create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid not null references public.products(id),
  batch_id uuid references public.stock_batches(id),
  quantity numeric(12,3) not null check (quantity > 0),
  unit_price numeric(12,2) not null check (unit_price >= 0)
);
create table public.payments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid references public.orders(id),
  retailer_id uuid not null references public.retailers(id),
  received_by uuid not null references public.profiles(id),
  method public.payment_method not null,
  amount numeric(12,2) not null check (amount > 0),
  reference_no text,
  received_at timestamptz not null default now()
);
create table public.stock_movements (
  id uuid primary key default gen_random_uuid(),
  batch_id uuid not null references public.stock_batches(id),
  movement_type text not null check (movement_type in ('purchase','sale','return_in','damage','expiry','adjustment')),
  quantity numeric(12,3) not null check (quantity > 0),
  reference_order_id uuid references public.orders(id),
  recorded_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.retailers enable row level security;
alter table public.products enable row level security;
alter table public.stock_batches enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.payments enable row level security;
alter table public.stock_movements enable row level security;

-- Minimal safe policies: no writes granted here. Add/test role-aware policies before app use.
create policy "read own profile" on public.profiles
for select to authenticated using (id = auth.uid());
create policy "read active product catalogue" on public.products
for select to authenticated using (is_active = true);

-- Implement admin/salesman/retailer-specific policies and server-side transactional
-- order confirmation, FEFO stock allocation, and payment reconciliation before production.
